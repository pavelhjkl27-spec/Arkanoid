from Project_for_Python_Arkanoid.backend.app import create_app

app = create_app()


if __name__ == '__main__':
    app.run()

